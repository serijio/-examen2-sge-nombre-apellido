"""Hacer un script que configure un nuevo JSON de nombre libraries-and-books.json que contenga una lista de objetos library en el que cada uno contiene la lista de objetos libro que le pertenecen en
los que habrá un campo userId con el usuario correspondiente que tiene el libro prestado. Pasar esa
estructura a un dataframe de pandas que lo mande a un excel cuyo nombre sea la fecha de hoy +
libros-prestados (eemploj: 20-mayo-libros-prestados.xlsx)"""