import hashlib
import json
import pandas as pd
import os

path = r'../users.json'
users = []
passwords = []


def hash_contrasena(user_password):
    pass_bytes = user_password.encode('utf-8')

    hasher = hashlib.sha256()
    hasher.update(pass_bytes)
    hash_ingresado = hasher.hexdigest()

    return hash_ingresado


with open(path, 'r') as file:
    data = json.load(file)
    newData = []

    for persona in data:
        hash_pass = hash_contrasena(persona['password'])
        users.append(persona['userId'])
        passwords.append(hash_pass)


file = "secure-users.json"

with open(file, 'w') as json_file:
    json.dump(data, json_file, indent=2)
