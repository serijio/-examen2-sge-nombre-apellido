import hashlib
import pandas as pd
import json

"""Hacer un script tabla_users.py que introduzca a los usuarios con sus contraseñas hasheadas en un
excel llamado usuarios.xlsx usando pandas y openpyxl (integrado en pandas)"""

path = r'../users.json'

users = []
passwords = []


def hash_contrasena(user_password):
    pass_bytes = user_password.encode('utf-8')

    hasher = hashlib.sha256()
    hasher.update(pass_bytes)
    hash_ingresado = hasher.hexdigest()

    return hash_ingresado


with open(path, 'r') as file:
    data = json.load(file)

    for persona in data:
        hash_pass = hash_contrasena(persona['password'])
        users.append(persona['userName'])
        passwords.append(hash_pass)

df = pd.DataFrame(
    {'Nombre': users, 'Contraseña hasheada': passwords}
)

df.to_excel("usuarios" + '.xlsx')
